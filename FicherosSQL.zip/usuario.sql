CREATE USER 'ruben'@'localhost' IDENTIFIED BY '12345';
GRANT ALL PRIVILEGES ON bd_incidencias.* TO 'ruben'@'localhost';
FLUSH PRIVILEGES;